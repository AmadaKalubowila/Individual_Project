package com.freshsip.billservice;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BillingService {

    @Autowired
    private BillingRepo billingRepository;

    @Autowired
    private RestTemplate restTemplate;

    public OrderDTO getOrderById(Long cartId) {
        return restTemplate.getForObject("http://localhost:8082/orders/" + cartId, OrderDTO.class);
    }

    @Autowired
    private ModelMapper modelMapper;

    private BillingDTO convertToDTO(Billing billing) {
        return modelMapper.map(billing, BillingDTO.class);
    }

    private Billing convertToEntity(BillingDTO billingDTO) {
        return modelMapper.map(billingDTO, Billing.class);
    }

    public List<BillingDTO> getAllBills() {
        return billingRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<BillingDTO> getBillById(int id) {
        return billingRepository.findById(id).map(this::convertToDTO);
    }

    public BillingDTO createBill(BillingDTO billingDTO) {
        Billing billing = convertToEntity(billingDTO);

        OrderDTO order = getOrderById(billingDTO.getCartId());
        Double fullTotal = order != null ? order.getFull_total() : 0.0;


        billing.setFullTotal(fullTotal);

        Billing savedBilling = billingRepository.save(billing);
        return convertToDTO(savedBilling);
    }


    public BillingDTO updateBill(int id, BillingDTO updatedBillDTO) {
        return billingRepository.findById(id).map(existingBill -> {
            // Update the cash and balance
            existingBill.setCash(updatedBillDTO.getCash());
            existingBill.setBalance(updatedBillDTO.getBalance());

            // Save the updated bill
            Billing updatedBill = billingRepository.save(existingBill);

            return convertToDTO(updatedBill);
        }).orElseThrow(() -> new RuntimeException("Bill not found with id " + id));
    }


    public void deleteBill(int id) {
        billingRepository.deleteById(id);
    }
}
